--- 
title: "A Minimal Bookdown Book"
author: "Sean Kross"
date: "2016-12-09"
site: bookdown::bookdown_site
documentclass: book
bibliography: [book.bib]
biblio-style: apalike
link-citations: yes
github-repo: seankross/bookdown-start
url: 'http\://seankross.com/bookdown-start/'
description: "Everything you need (and nothing more) to start a bookdown book."
---

# Preface {-}

This is the very first part of the book.
