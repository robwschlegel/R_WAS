This is the absolute minimum you need to start a [bookdown](https://bookdown.org/home/about.html) book. You can find the
preview of this book at http://seankross.com/bookdown-start/

All of the content of this repository is licensed 
[CC0](https://creativecommons.org/publicdomain/zero/1.0/).
